package id.ac.uniska.pbo2.p05;

import java.awt.event.ActionEvent;

/**
 * @author author hafiz
 */
public class KalkulatorSederhana extends javax.swing.JFrame {

    /** Membuat form baru. */
    public KalkulatorSederhana() {
        initComponents();
        angka1Field.putClientProperty("JTextField.placeholderText", "Angka pertama");
        angka2Field.putClientProperty("JTextField.placeholderText", "Angka kedua");
        hasilLabel.putClientProperty("FlatLaf.styleClass", "h3");
        // Cara 2. Lambda ditulis sendiri di konstruktor, setelah initComponents()
        kaliButton.addActionListener(e -> hitung('x'));
        // Cara 3. Method reference: langsung menunjuk method hapus yang sudah ada
        hapusButton.addActionListener(this::hapus);
        pack();
    }

    /** Dipanggil oleh GUI Builder. Isinya dibuat otomatis, jangan diubah manual. */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        isiPanel = new javax.swing.JPanel();
        isianPanel = new javax.swing.JPanel();
        angka1Field = new javax.swing.JTextField();
        angka2Field = new javax.swing.JTextField();
        operatorPanel = new javax.swing.JPanel();
        tambahButton = new javax.swing.JButton();
        kurangButton = new javax.swing.JButton();
        kaliButton = new javax.swing.JButton();
        bagiButton = new javax.swing.JButton();
        bawahPanel = new javax.swing.JPanel();
        hasilLabel = new javax.swing.JLabel();
        hapusButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Kalkulator Sederhana");

        isiPanel.setBorder(javax.swing.BorderFactory.createEmptyBorder(16, 16, 16, 16));
        isiPanel.setLayout(new java.awt.GridLayout(3, 1, 0, 12));

        isianPanel.setLayout(new java.awt.GridLayout(1, 2, 8, 0));
        isianPanel.add(angka1Field);
        isianPanel.add(angka2Field);

        isiPanel.add(isianPanel);

        operatorPanel.setLayout(new java.awt.GridLayout(1, 4, 8, 0));

        tambahButton.setText("+");
        tambahButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tambahButtonActionPerformed(evt);
            }
        });
        operatorPanel.add(tambahButton);

        kurangButton.setText("-");
        kurangButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kurangButtonActionPerformed(evt);
            }
        });
        operatorPanel.add(kurangButton);

        kaliButton.setText("x");
        operatorPanel.add(kaliButton);

        bagiButton.setText("/");
        bagiButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bagiButtonActionPerformed(evt);
            }
        });
        operatorPanel.add(bagiButton);

        isiPanel.add(operatorPanel);

        bawahPanel.setLayout(new java.awt.BorderLayout(8, 0));

        hasilLabel.setText("Hasil: 0");
        bawahPanel.add(hasilLabel, java.awt.BorderLayout.CENTER);

        hapusButton.setText("Hapus");
        bawahPanel.add(hapusButton, java.awt.BorderLayout.EAST);

        isiPanel.add(bawahPanel);

        getContentPane().add(isiPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tambahButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tambahButtonActionPerformed
        // Cara 1. Event handler dibuat GUI Builder melalui Events, Action, actionPerformed
        hitung('+');
    }//GEN-LAST:event_tambahButtonActionPerformed

    private void kurangButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kurangButtonActionPerformed
        hitung('-');
    }//GEN-LAST:event_kurangButtonActionPerformed

    private void bagiButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bagiButtonActionPerformed
        hitung('/');
    }//GEN-LAST:event_bagiButtonActionPerformed

    private void hitung(char operator) {
        try {
            double a = Double.parseDouble(angka1Field.getText().trim());
            double b = Double.parseDouble(angka2Field.getText().trim());
            if (operator == '/' && b == 0) {
                hasilLabel.setText("Tidak dapat membagi dengan nol");
                return;
            }
            double hasil = switch (operator) {
                case '+' -> a + b;
                case '-' -> a - b;
                case 'x' -> a * b;
                default -> a / b;
            };
            hasilLabel.setText("Hasil: " + rapikan(a) + " " + operator + " "
                    + rapikan(b) + " = " + rapikan(hasil));
        } catch (NumberFormatException ex) {
            hasilLabel.setText("Isi kedua angka dengan benar");
        }
    }

    private void hapus(ActionEvent e) {
        angka1Field.setText("");
        angka2Field.setText("");
        hasilLabel.setText("Hasil: 0");
        angka1Field.requestFocusInWindow(); // kursor kembali ke isian pertama
    }

    /** Menampilkan bilangan bulat tanpa ".0", misalnya 12.0 menjadi 12. */
    private static String rapikan(double nilai) {
        if (nilai == Math.rint(nilai)) {
            return String.valueOf((long) nilai);
        }
        return String.valueOf(nilai);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        try {
            javax.swing.UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
        } catch (Exception ex) {
            System.err.println("FlatLaf tidak tersedia, memakai tampilan bawaan.");
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new KalkulatorSederhana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField angka1Field;
    private javax.swing.JTextField angka2Field;
    private javax.swing.JButton bagiButton;
    private javax.swing.JPanel bawahPanel;
    private javax.swing.JButton hapusButton;
    private javax.swing.JLabel hasilLabel;
    private javax.swing.JPanel isianPanel;
    private javax.swing.JPanel isiPanel;
    private javax.swing.JButton kaliButton;
    private javax.swing.JButton kurangButton;
    private javax.swing.JPanel operatorPanel;
    private javax.swing.JButton tambahButton;
    // End of variables declaration//GEN-END:variables
}
